<?php
// ملف بروكسي خارق لتنظيف ومطابقة أسماء الشركات مهما كانت الرموز والمسافات
header('Content-Type: image/png');

$company = isset($_GET['company']) ? $_GET['company'] : '';

// 1. تنظيف النص تماماً: تحويله لحروف صغيرة، وحذف الشرطات والرموز الزائدة
$company_clean = mb_strtolower($company, 'UTF-8');
$company_clean = str_replace(['-', '_', '/', '\\', '|', ',', '.', '(', ')'], ' ', $company_clean);

// حذف المسافات المتكررة وتحويلها لمسافة واحدة، ثم إزالة المسافات من الأطراف تماماً
$company_clean = preg_replace('/\s+/', ' ', $company_clean); 
$company_clean = trim($company_clean); 

// 2. مصفوفة الشعارات الأصلية
$logos = [
// استبدل السطر الخطأ بهذا:
'google' => 'https://img.icons8.com/color/144/google-logo.png',
   'amazon' => "https://img.icons8.com/color/144/amazon-logo.png",
    'microsoft'   => "https://img.icons8.com/color/144/microsoft.png",
'apple'   => "https://images.weserv.nl/?url=img.icons8.com/macapp/144/apple-logo.png",
    'meta'        => "https://img.icons8.com/color/144/meta-platforms.png",
    'tesla'       => "https://img.icons8.com/color/144/tesla-logo.png",
    'netflix'     => "https://img.icons8.com/color/144/netflix-desktop-app--v1.png",
    'uber'        => "https://img.icons8.com/universal-groups/144/uber.png",
    'spotify'     => "https://img.icons8.com/color/144/spotify--v1.png",
    'samsung'     => "https://img.icons8.com/color/144/samsung.png",
    'huawei'      => "https://img.icons8.com/color/144/huawei.png",
    'alibaba'     => "https://img.icons8.com/color/144/alibaba.png",
    'oracle'      => "https://img.icons8.com/color/144/oracle-logo.png",
    'intel'       => "https://img.icons8.com/color/144/intel.png",
    'ibm'         => "https://img.icons8.com/color/144/ibm.png",
    'adobe'       => "https://img.icons8.com/color/144/adobe-systems.png",
    'nvidia'      => "https://img.icons8.com/color/144/nvidia.png",
    'dell'        => "https://img.icons8.com/color/144/dell.png",
    'hp'          => "https://img.icons8.com/color/144/hp.png",
   'sony'   => "https://img.icons8.com/ios-filled/144/sony.png",
    'tiktok'      => "https://img.icons8.com/color/144/tiktok.png",
    'paypal'      => "https://img.icons8.com/color/144/paypal.png",
    'stripe'      => "https://img.icons8.com/color/144/stripe.png",
    'airbnb'      => "https://img.icons8.com/color/144/airbnb.png",
    'zoom'        => "https://img.icons8.com/color/144/zoom.png",
'cisco'   => "https://images.weserv.nl/?url=img.icons8.com/color/144/cisco.png",
    'sap'         => "https://img.icons8.com/color/144/sap.png",
    'salesforce'  => "https://img.icons8.com/color/144/salesforce.png"
];

// الأيقونة الزرقاء الافتراضية
$default_url = "https://img.icons8.com/fluency/96/company.png";
$url = $default_url;

// 3. الفحص الذكي: يبحث عن المفتاح داخل النص المنظف
foreach ($logos as $key => $src) {
    if (strpos($company_clean, $key) !== false) {
        $url = $src;
        break;
    }
}

// إعداد الطلب الآمن
$options = [
    "http" => [
        "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n"
    ]
];
$context = stream_context_create($options);

// جلب الصورة وعرضها للمتصفح رغماً عن قيود الاستضافة المجانية
$image_data = @file_get_contents($url, false, $context);

if ($image_data === false || empty($image_data)) {
    echo @file_get_contents($default_url, false, $context);
} else {
    echo $image_data;
}
exit;