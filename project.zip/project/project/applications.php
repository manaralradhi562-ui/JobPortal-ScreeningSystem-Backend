<?php
session_start();
include("db.php");

/* =========================
   🔹 جلب job_id بأمان
========================= */
$job_id = $_GET['job_id'] ?? 0;

if($job_id == 0){
    die("❌ لم يتم تحديد الوظيفة");
}

/* =========================
   🔹 تحديث حالة الطلب
========================= */
if(isset($_GET['action']) && isset($_GET['app_id'])){

    $id = intval($_GET['app_id']);
    $action = $_GET['action'];

    $stmt = $conn->prepare("UPDATE applications SET status=? WHERE id=?");
    $stmt->bind_param("si", $action, $id);
    $stmt->execute();

    $stmt2 = $conn->prepare("SELECT * FROM applications WHERE id=?");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $app = $stmt2->get_result()->fetch_assoc();

    if($app){

        $msg = ($action == "accepted") ? "تم قبولك 🎉" : "تم رفضك ❌";

        $stmt3 = $conn->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)");
        $type = "job";
        $stmt3->bind_param("iss", $app['user_id'], $msg, $type);
        $stmt3->execute();
    }
}

/* =========================
   🔹 جلب المتقدمين
========================= */
$stmt = $conn->prepare("
    SELECT applications.*, users.username 
    FROM applications 
    JOIN users ON applications.user_id = users.id 
    WHERE job_id = ?
");

$stmt->bind_param("i", $job_id);
$stmt->execute();
$apps = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>لوحة المتقدمين</title>

<style>

/* =========================
   🌐 إعدادات عامة
========================= */
body{
    font-family:Tahoma;
    margin:0;
    direction:rtl;
    background:linear-gradient(135deg,#0f172a,#111827);
    color:#fff;
}

/* =========================
   🔥 العنوان
========================= */
h2{
    text-align:center;
    margin:25px 0;
    font-size:24px;
}

/* =========================
   📦 الحاوية
========================= */
.container{
    max-width:900px;
    margin:auto;
    padding:20px;
}

/* =========================
   👤 كرت المتقدم
========================= */
.box{
    background:rgba(255,255,255,0.06);
    backdrop-filter: blur(15px);
    padding:18px;
    margin:15px 0;
    border-radius:18px;
    box-shadow:0 15px 40px rgba(0,0,0,0.4);
    transition:0.3s;
}

.box:hover{
    transform:translateY(-3px);
}

/* =========================
   👤 الاسم
========================= */
.box h3{
    margin:0;
}

/* =========================
   📌 الحالة
========================= */
.status{
    margin:8px 0;
    padding:5px 10px;
    display:inline-block;
    border-radius:8px;
    background:#1f2937;
}

/* =========================
   🔘 أزرار
========================= */
a{
    display:inline-block;
    margin-top:10px;
    text-decoration:none;
    padding:8px 14px;
    border-radius:10px;
    font-weight:bold;
    transition:0.3s;
}

.accept{
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:white;
}

.reject{
    background:linear-gradient(135deg,#ef4444,#dc2626);
    color:white;
}

a:hover{
    transform:scale(1.05);
}

/* =========================
   ❌ لا يوجد
========================= */
.empty{
    text-align:center;
    margin-top:50px;
    color:#aaa;
    font-size:18px;
}

</style>
</head>

<body>

<h2>📄 المتقدمين للوظيفة</h2>

<div class="container">

<?php if($apps->num_rows == 0){ ?>

    <div class="empty">لا يوجد متقدمين حالياً</div>

<?php } ?>

<?php while($a = $apps->fetch_assoc()){ ?>

<div class="box">

    <h3>👤 <?= htmlspecialchars($a['username']) ?></h3>

    <div class="status">
        📌 الحالة: <?= htmlspecialchars($a['status']) ?>
    </div>

    <br>

    <a class="accept" href="?job_id=<?= $job_id ?>&app_id=<?= $a['id'] ?>&action=accepted">
        ✔ قبول
    </a>

    <a class="reject" href="?job_id=<?= $job_id ?>&app_id=<?= $a['id'] ?>&action=rejected">
        ❌ رفض
    </a>

</div>

<?php } ?>

</div>

</body>
</html>