<?php
include("db.php");
$q = isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '';

// استعلام البحث مع جلب اسم الشركة
$query = "SELECT jobs.*, companies.company_name 
          FROM jobs 
          LEFT JOIN companies ON jobs.company_id = companies.id 
          WHERE jobs.title LIKE '%$q%' 
          ORDER BY jobs.id DESC";
$results = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتائج البحث عن: <?= $q ?></title>
    <style>
        :root { --primary: #2563eb; --dark: #1e293b; --light: #f8fafc; }
        body { background-color: var(--light); font-family: 'Segoe UI', Tahoma, sans-serif; margin: 0; padding-bottom: 50px; }
        
        /* Header بسيط للنتائج */
        .search-header { background: white; padding: 20px 5%; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 40px; }
        
        .container { max-width: 1200px; margin: auto; padding: 0 20px; }
        .jobs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 25px; }
        
        .job-card { background: white; padding: 25px; border-radius: 20px; border: 1px solid #e2e8f0; transition: 0.3s; text-align: center; }
        .job-card:hover { transform: translateY(-10px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .company-img { width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px; border-radius: 10px; }
        
        .btn-view { display: inline-block; background: var(--primary); color: white; padding: 10px 25px; border-radius: 10px; text-decoration: none; margin-top: 15px; }
        .no-results { text-align: center; padding: 50px; font-size: 1.5rem; color: #64748b; }
        .back-link { display: block; margin-top: 30px; text-align: center; color: var(--primary); text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<header class="search-header">
    <a href="index.php" style="text-decoration:none; color:var(--primary); font-weight:bold;">← العودة للرئيسية</a>
</header>

<div class="container">
    <h2>نتائج البحث عن: "<?= $q ?>"</h2>
    <br>
    
    <div class="jobs-grid">
        <?php if($results->num_rows > 0): ?>
            <?php while($job = $results->fetch_assoc()): ?>
                <div class="job-card">
                    <img src="proxy.php?company=<?= urlencode($job['company_name'] ?? 'logo') ?>" 
                         class="company-img" onerror="this.src='images/logo.png'">
                         
                    <h3 style="margin-bottom: 10px;"><?= htmlspecialchars($job['title']) ?></h3>
                    <p style="color: #64748b;"><?= htmlspecialchars($job['company_name'] ?? 'شركة غير معروفة') ?></p>
                    
                    <a href="job.php?id=<?= $job['id'] ?>" class="btn-view">عرض التفاصيل</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="no-results">
                <p>عذراً، لم يتم العثور على وظائف تطابق بحثك.</p>
                <a href="index.php" class="back-link">تصفح جميع الوظائف</a>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>