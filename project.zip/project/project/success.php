<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>تم الإرسال</title>

<style>

body{
    margin:0;
    font-family:Tahoma;
    direction:rtl;
    background:linear-gradient(135deg,#0f172a,#111827);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    color:#fff;
}

/* الكرت */
.card{
    text-align:center;
    background:rgba(255,255,255,0.06);
    backdrop-filter: blur(15px);
    padding:40px 30px;
    border-radius:20px;
    box-shadow:0 20px 50px rgba(0,0,0,0.4);
    animation: pop 0.6s ease;
}

/* أنيميشن دخول */
@keyframes pop{
    from{transform:scale(0.8); opacity:0;}
    to{transform:scale(1); opacity:1;}
}

/* علامة الصح */
.icon{
    font-size:60px;
    color:#00ffcc;
    margin-bottom:10px;
}

/* النص */
h2{
    margin:10px 0;
}

/* الزر */
a{
    display:inline-block;
    margin-top:15px;
    padding:12px 20px;
    background:linear-gradient(90deg,#00c6ff,#0072ff);
    color:white;
    text-decoration:none;
    border-radius:12px;
    transition:0.3s;
}

a:hover{
    transform:scale(1.05);
    box-shadow:0 10px 20px rgba(0,114,255,0.3);
}

</style>
</head>

<body>

<div class="card">

    <div class="icon">✔</div>

    <h2>تم إرسال طلبك بنجاح</h2>
    <p>سيتم مراجعة إجاباتك من قبل الشركة</p>

    <a href="index.php">العودة للرئيسية</a>

</div>

</body>
</html>