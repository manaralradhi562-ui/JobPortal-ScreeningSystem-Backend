<?php
header('Content-Type: text/html; charset=utf-8');
include("db.php");
$id = intval($_GET['id'] ?? 0);

// استعلام لجلب بيانات الوظيفة والشركة
$stmt = $conn->prepare("SELECT jobs.*, companies.company_name FROM jobs JOIN companies ON jobs.company_id = companies.id WHERE jobs.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$job = $result->fetch_assoc();

// المصفوفة الكاملة مع إضافة الوصف، المجال، والخبرة
$data = [
    1 => ['img' => 'images/imagesgoogle.png.png', 'desc' => 'رواد الذكاء الاصطناعي وبحوث المستقبل', 'field' => 'الذكاء الاصطناعي', 'exp' => 'خبرة 3 سنوات في تعلم الآلة'],
    2 => ['img' => 'images/image.jfif', 'desc' => 'منصة التجارة الإلكترونية الأكبر في العالم', 'field' => 'التجارة الإلكترونية', 'exp' => 'خبرة في إدارة قواعد البيانات الضخمة'],
    3 => ['img' => 'images/تنزيل(2).jfif', 'desc' => 'المطور الأول لأنظمة ويندوز وبرمجيات الأعمال', 'field' => 'تطوير البرمجيات', 'exp' => 'إتقان C# و .NET Framework'],
    4 => ['img' => 'images/تنزيل.png', 'desc' => 'شركة الابتكار في الأجهزة وتطبيقات iOS', 'field' => 'تطوير تطبيقات الجوال', 'exp' => 'خبرة في لغة Swift و Xcode'],
    5 => ['img' => 'images/تنزيل(3).jfif', 'desc' => 'عملاق المنصات الاجتماعية والواقع الافتراضي', 'field' => 'الشبكات الاجتماعية', 'exp' => 'خبرة في React و Node.js'],
    6 => ['img' => 'images/تنزيل (4).jfif', 'desc' => 'رواد السيارات الكهربائية والطاقة المستدامة', 'field' => 'الهندسة والسيارات', 'exp' => 'خبرة في الأنظمة المدمجة'],
    7 => ['img' => 'images/تنزيل(1).png', 'desc' => 'أكبر منصة لبث المحتوى المرئي في العالم', 'field' => 'البث الرقمي', 'exp' => 'خبرة في أنظمة التوزيع (Streaming)'],
    8 => ['img' => 'images/تنزيل(2).png', 'desc' => 'تقنيات النقل الذكي والتنقل التشاركي', 'field' => 'حلول النقل', 'exp' => 'خبرة في تطوير الواجهات البرمجية APIs'],
    9 => ['img' => 'images/تنزيل (3).png', 'desc' => 'المنصة الرائدة لخدمات الموسيقى والبث الرقمي', 'field' => 'الخدمات الصوتية', 'exp' => 'خبرة في تقنيات معالجة الصوت'],
    10 => ['img' => 'images/تنزيل (5).png', 'desc' => 'العملاق الكوري في تصنيع الإلكترونيات والأجهزة', 'field' => 'الإلكترونيات', 'exp' => 'خبرة في صيانة الهاردوير'],
    11 => ['img' => 'images/تنزيل (6).png', 'desc' => 'رواد حلول الشبكات وتقنيات الجيل الخامس 5G', 'field' => 'الاتصالات والشبكات', 'exp' => 'شهادة معتمدة في الشبكات'],
    12 => ['img' => 'images/تنزيل (18).png', 'desc' => 'عملاق التجارة الإلكترونية في الأسواق العالمية', 'field' => 'إدارة المبيعات', 'exp' => 'خبرة في تحليل الأسواق'],
    13 => ['img' => 'images/تنزيل (8).png', 'desc' => 'الخبراء في قواعد البيانات ونظم الشركات', 'field' => 'قواعد البيانات', 'exp' => 'إدارة خوادم SQL و Oracle'],
    14 => ['img' => 'images/تنزيل (9).png', 'desc' => 'المصنع الأول للمعالجات الدقيقة في العالم', 'field' => 'تصنيع أشباه الموصلات', 'exp' => 'هندسة المعالجات'],
    15 => ['img' => 'images/تنزيل (10).png', 'desc' => 'أبحاث الذكاء الاصطناعي والحلول التقنية المتقدمة', 'field' => 'الأبحاث والتقنية', 'exp' => 'درجة علمية متقدمة في علوم الحاسب'],
    16 => ['img' => 'images/تنزيل (11).png', 'desc' => 'أدوات التصميم والإبداع الرقمي', 'field' => 'التصميم الجرافيكي', 'exp' => 'إجادة برامج Adobe Creative Cloud'],
    17 => ['img' => 'images/تنزيل (12).png', 'desc' => 'رواد المعالجات الرسومية والذكاء الاصطناعي', 'field' => 'الرسوميات (GPU)', 'exp' => 'خبرة في البرمجة منخفضة المستوى'],
    18 => ['img' => 'images/تنزيل (13).png', 'desc' => 'حلول أجهزة الكمبيوتر الشخصية والخوادم', 'field' => 'دعم الأنظمة', 'exp' => 'خبرة في صيانة الخوادم'],
    19 => ['img' => 'images/تنزيل (14).png', 'desc' => 'حلول الطابعات والأنظمة المكتبية', 'field' => 'حلول مكاتب', 'exp' => 'خبرة في أنظمة الطباعة الذكية'],
    20 => ['img' => 'images/تنزيل (15).png', 'desc' => 'الرواد في عالم الألعاب والإلكترونيات', 'field' => 'تطوير الألعاب', 'exp' => 'خبرة في محركات الألعاب Unity/Unreal'],
    21 => ['img' => 'images/تنزيل (16).png', 'desc' => 'منصة الفيديو الأكثر انتشاراً عالمياً', 'field' => 'تطوير الوسائط', 'exp' => 'خبرة في تطوير تطبيقات الويب'],
    22 => ['img' => 'images/تنزيل (5).jfif', 'desc' => 'نظام المدفوعات الإلكترونية الأكثر أماناً', 'field' => 'التكنولوجيا المالية', 'exp' => 'خبرة في الأمن السيبراني'],
    23 => ['img' => 'images/تنزيل (17).png', 'desc' => 'بنية تحتية متطورة للمدفوعات الرقمية', 'field' => 'البنية التحتية المالية', 'exp' => 'خبرة في الأنظمة المالية'],
    24 => ['img' => 'images/تنزيل (18).png', 'desc' => 'منصة عالمية لحجوزات السكن والضيافة', 'field' => 'السياحة والسفر', 'exp' => 'تطوير أنظمة الحجز'],
    25 => ['img' => 'images/تنزيل (6).jfif', 'desc' => 'رواد حلول الاجتماعات المرئية والتعاون عن بعد', 'field' => 'العمل عن بعد', 'exp' => 'خبرة في تقنيات WebRTC'],
    26 => ['img' => 'images/تنزيل (7).jfif', 'desc' => 'أكبر شركة في تقنيات الشبكات والربط', 'field' => 'الشبكات والاتصالات', 'exp' => 'خبرة في توجيه البيانات (Routing)'],
    27 => ['img' => 'images/تنزيل (8).jfif', 'desc' => 'نظم إدارة موارد الشركات (ERP) العالمية', 'field' => 'إدارة الأعمال', 'exp' => 'خبرة في أنظمة SAP'],
    28 => ['img' => 'images/تنزيل (19).png', 'desc' => 'منصة السحابية الأولى لإدارة علاقات العملاء', 'field' => 'سحابة و CRM', 'exp' => 'خبرة في إدارة العملاء (Salesforce)'],
];

$c_id = $job['company_id'] ?? 0;
$jobData = isset($data[$c_id]) ? $data[$c_id] : ['img' => 'images/default.png', 'desc' => 'شركة رائدة تسعى لضم أفضل الكفاءات.', 'field' => 'غير محدد', 'exp' => 'غير محدد'];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $job ? htmlspecialchars($job['title']) : 'وظيفة غير موجودة' ?> | وظيفتي 2026</title>
    <style>
        :root { 
            --primary: #2563eb; 
            --dark: #1e293b; 
            --light: #f8fafc; 
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        body { 
            background: var(--light); 
            padding: 30px 15px; 
            color: var(--dark); 
            line-height: 1.7;
            overflow-x: hidden;
        }
        .container { 
            max-width: 800px; 
            margin: 0 auto; 
            background: #fff; 
            padding: 35px 25px; 
            border-radius: 24px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.04); 
        }
        .header-section { 
            text-align: center; 
            margin-bottom: 30px; 
        }
        
        /* تحسين صورة اللوجو لتناسب الـ Container بشكل مميز */
        .job-img { 
            width: 140px; 
            height: 140px; 
            object-fit: contain; 
            border-radius: 20px; 
            border: 4px solid #f1f5f9; 
            padding: 10px; 
            background: white; 
            margin-bottom: 15px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.02);
        }
        h1 { 
            font-size: 2rem; 
            margin-bottom: 8px; 
            font-weight: 700;
            color: var(--dark);
        }
        .company-name { 
            font-size: 1.2rem; 
            color: var(--primary); 
            font-weight: 600; 
            margin-bottom: 25px; 
        }
        
        /* جعل شبكة المعلومات متجاوبة بشكل كامل */
        .info-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); 
            gap: 15px; 
            margin-bottom: 25px; 
        }
        .info-card { 
            background: #f8fafc; 
            padding: 15px; 
            border-radius: 12px; 
            font-size: 0.95rem; 
            border: 1px solid #f1f5f9;
            text-align: right;
        }
        .info-card strong {
            color: #475569;
        }
        
        .content-box { 
            font-size: 1.05rem; 
            color: #334155;
        }
        .content-box h4 { 
            margin-top: 25px; 
            color: var(--dark); 
            font-size: 1.2rem; 
            border-right: 4px solid var(--primary);
            padding-right: 10px;
            margin-bottom: 10px;
        }
        .content-box p {
            margin-bottom: 15px;
            text-align: justify;
        }
        
        .salary-box { 
            background: #eff6ff; 
            padding: 20px; 
            border-radius: 16px; 
            margin: 30px 0; 
            border: 2px dashed var(--primary); 
            text-align: center; 
            font-weight: 700; 
            font-size: 1.15rem;
            color: var(--primary);
        }
        .apply-btn { 
            display: block; 
            background: var(--primary); 
            color: white; 
            padding: 16px; 
            text-align: center; 
            border-radius: 16px; 
            text-decoration: none; 
            font-size: 1.15rem; 
            font-weight: bold; 
            transition: all 0.2s ease; 
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.2);
        }
        .apply-btn:hover { 
            background: #1d4ed8; 
            transform: translateY(-2px);
        }

        /* تحسينات الشاشات الصغيرة والهواتف البسيطة */
        @media (max-width: 480px) {
            body {
                padding: 15px 10px;
            }
            .container { 
                padding: 25px 15px; 
                border-radius: 16px;
            }
            .job-img { 
                width: 110px; 
                height: 110px; 
                border-radius: 16px;
            }
            h1 { 
                font-size: 1.5rem; 
            }
            .company-name { 
                font-size: 1.05rem; 
                margin-bottom: 20px;
            }
            .info-grid {
                grid-template-columns: 1fr; /* تحويل الكروت لعمود واحد لتجنب الضيق */
                gap: 10px;
            }
            .info-card {
                padding: 12px;
                font-size: 0.9rem;
            }
            .content-box { 
                font-size: 0.95rem; 
            }
            .content-box h4 {
                font-size: 1.1rem;
            }
            .salary-box {
                padding: 15px;
                font-size: 1rem;
                margin: 25px 0;
            }
            .apply-btn {
                padding: 14px;
                font-size: 1.05rem;
                border-radius: 12px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <?php if($job): ?>
        <div class="header-section">
            <img src="<?= $jobData['img'] ?>" class="job-img" onerror="this.src='images/default.png'" alt="شعار الشركة">
            <h1><?= htmlspecialchars($job['title']) ?></h1>
            <p class="company-name"><?= htmlspecialchars($job['company_name']) ?></p>
            
            <div class="info-grid">
                <div class="info-card"><strong>💼 المجال:</strong> <?= htmlspecialchars($jobData['field']) ?></div>
                <div class="info-card"><strong>⏳ الخبرة المطلوبة:</strong> <?= htmlspecialchars($jobData['exp']) ?></div>
            </div>
        </div>
        <div class="content-box">
            <h4>💡 نبذة عن الشركة</h4>
            <p><?= htmlspecialchars($jobData['desc']) ?></p>
          
            <h4>📋 تفاصيل الوظيفة والشروط</h4>
            <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>
            
            <div class="salary-box">💰 الراتب المتوقع: <?= htmlspecialchars($job['salary']) ?></div>
        </div>
        <a href="apply.php?id=<?= $job['id'] ?>" class="apply-btn">🚀 تقديم طلب توظيف الآن</a>
    <?php else: ?>
        <div style="text-align:center; padding: 20px 0;">
            <h2 style="margin-bottom: 15px; font-size: 1.4rem;">عذراً، الوظيفة غير موجودة.</h2>
            <a href="index.php" style="color: var(--primary); text-decoration: none; font-weight: bold;">العودة للرئيسية</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>