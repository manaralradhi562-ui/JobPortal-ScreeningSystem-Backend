<?php
// 🛠️ تفعيل إظهار الأخطاء للمساعدة في التتبع أثناء التطوير
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 🎯 بيانات الاتصال الخاصة بحسابك على InfinityFree:
$hostname = "sql110.infinityfree.com"; 
$username = "if0_42158107";          
$password = "KleKARUsUOS";          
$database = "if0_42158107_jobportal";

// 1. إنشاء الاتصال بالسيرفر وقاعدة البيانات
$conn = @new mysqli($hostname, $username, $password, $database);

// 2. التحقق من نجاح الاتصال
if ($conn->connect_error) {
    die("<div style='direction:rtl; text-align:center; padding:20px; font-family:Tahoma; color:red; border:2px solid red; background:#fff5f5; border-radius:10px; max-width:600px; margin:50px auto;'>
        <h3>❌ فشل الاتصال بقاعدة البيانات!</h3>
        <p><b>السبب المحتمل:</b> السيرفر متوقف مؤقتاً أو هناك خطأ في البيانات أعلاه.</p>
        <p style='direction:ltr; background:#eee; padding:10px; border-radius:5px;'>Error: " . $conn->connect_error . "</p>
    </div>");
}

// 3. ضبط ترميز اللغة العربية لضمان قراءة النصوص العربية والأسماء بشكل صحيح
$conn->set_charset("utf8mb4");

// هنا المتغير $conn جاهز تماماً للاستخدام في بقية صفحات الموقع لاستدعاء البيانات
?>