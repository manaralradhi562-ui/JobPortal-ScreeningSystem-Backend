<?php
session_start();
include("db.php");
include("data.php"); // استدعاء مصفوفة الصور والأوصاف

// جلب الوظائف
$jobs = $conn->query("SELECT jobs.*, companies.company_name FROM jobs LEFT JOIN companies ON jobs.company_id = companies.id ORDER BY jobs.id DESC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>وظيفتي 2026 | المنصة الرائدة للتوظيف وبوابة الوظائف</title>
    <meta name="description" content="منصة بوابة وظيفتي 2026 للتوظيف، تصفح واكتشف أحدث الوظائف الشاغرة والفرص المهنية المتاحة لدى كبرى الشركات وقدم عليها بكل سهولة.">
    <meta name="keywords" content="وظيفتي, وظيفتي 2026, بوابة التوظيف, وظائف شاغرة, توظيف, تقديم على وظائف, wazifaty, wazifaty portal">
    <meta name="robots" content="index, follow">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "وظيفتي 2026",
      "alternateName": "بوابة وظيفتي للتوظيف",
      "url": "https://wazifaty-portal.infinityfreeapp.com/"
    }
    </script>
    
    <style>
        :root { 
            --primary: #2563eb; 
            --dark: #1e293b; 
            --light: #f8fafc; 
        }
        * { 
            margin:0; 
            padding:0; 
            box-sizing:border-box; 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            -webkit-tap-highlight-color: transparent;
        }
        body { 
            background-color: var(--light); 
            color: var(--dark); 
            line-height: 1.6; 
            overflow-x: hidden; /* يمنع ظهور شريط التمرير الأفقي المزعج في الهواتف */
        }
        
        /* الهيدر المتجاوب */
        header { 
            background: white; 
            padding: 1rem 5%; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05); 
        }
        .logo-text { 
            font-size: 1.5rem; 
            font-weight: 800; 
            color: var(--primary); 
        }
        .nav-links { 
            display: flex; 
            gap: 20px; 
            align-items: center;
        }
        .nav-links a { 
            text-decoration: none; 
            color: var(--dark); 
            font-weight: 600; 
            font-size: 0.95rem; 
            transition: color 0.2s;
        }
        .nav-links a:hover { 
            color: var(--primary); 
        }

        /* قسم البحث المحسّن للهواتف */
        .hero { 
            background: linear-gradient(135deg, #1e293b, #0f172a); 
            color: white; 
            padding: 50px 20px; 
            text-align: center; 
        }
        .hero h1 {
            font-size: 2rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .search-container { 
            background: white; 
            padding: 6px; 
            border-radius: 30px; /* تصميم دائري وعصري للمحرك */
            display: flex; 
            width: 100%; 
            max-width: 600px; 
            margin: 25px auto 0; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        .search-container input { 
            border: none; 
            padding: 12px 20px; 
            flex: 1; 
            outline: none; 
            border-radius: 30px; 
            font-size: 1rem; 
        }
        .search-container button { 
            background: var(--primary); 
            color: white; 
            border: none; 
            padding: 0 25px; 
            border-radius: 30px; 
            cursor: pointer; 
            font-weight: bold; 
            transition: background 0.2s;
        }
        .search-container button:hover {
            background: #1d4ed8;
        }

        /* الشبكة والبطاقات */
        .container { 
            max-width: 1200px; 
            margin: 40px auto; 
            padding: 0 20px; 
        }
        .jobs-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); 
            gap: 20px; 
        }
        .job-card { 
            background: white; 
            padding: 25px; 
            border-radius: 20px; 
            border: 1px solid #e2e8f0; 
            transition: all 0.3s ease; 
            text-align: center; 
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .job-card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 10px 20px rgba(0,0,0,0.06); 
        }
        .company-img { 
            width: 70px; 
            height: 70px; 
            object-fit: contain; 
            margin: 0 auto 15px; 
            border-radius: 12px; 
            padding: 5px;
            background: #f8fafc;
            border: 1px solid #f1f5f9;
        }
        .job-card h3 {
            font-size: 1.2rem;
            color: var(--dark);
            margin-bottom: 5px;
        }
        .btn-view { 
            display: block; 
            background: #eff6ff; 
            color: var(--primary); 
            text-align: center; 
            padding: 12px; 
            border-radius: 12px; 
            text-decoration: none; 
            margin-top: 15px; 
            font-weight: 600; 
            transition: all 0.2s;
        }
        .btn-view:hover {
            background: var(--primary);
            color: white;
        }

        /* تحسينات قوية مخصصة للهواتف الشاشات الصغيرة */
        @media (max-width: 600px) {
            header { 
                flex-direction: column; 
                gap: 15px;
                padding: 15px 20px;
                text-align: center; 
            }
            .logo-text {
                font-size: 1.4rem;
            }
            .nav-links { 
                width: 100%;
                justify-content: center;
                gap: 15px; 
            }
            .nav-links a {
                font-size: 0.9rem;
            }
            .hero { 
                padding: 40px 15px; 
            }
            .hero h1 {
                font-size: 1.6rem;
            }
            .search-container {
                margin-top: 15px;
                border-radius: 15px;
                flex-direction: column;
                background: transparent;
                box-shadow: none;
                gap: 10px;
            }
            .search-container input {
                background: white;
                border-radius: 12px;
                padding: 14px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .search-container button {
                padding: 14px;
                border-radius: 12px;
                width: 100%;
                box-shadow: 0 2px 8px rgba(37, 99, 235, 0.3);
            }
            .container {
                margin: 25px auto;
                padding: 0 15px;
            }
            .jobs-grid { 
                grid-template-columns: 1fr; /* عرض بطاقة واحدة كاملة العرض في شاشة الهاتف */
                gap: 15px;
            }
            .job-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="logo-text">وظيفتي 2026</div>
    <nav class="nav-links">
        <a href="index.php">الرئيسية</a>
        <a href="index.php">الوظائف</a>
        <?php if(!isset($_SESSION['user_id'])): ?>
            <a href="login.php" style="color:var(--primary)">تسجيل الدخول</a>
        <?php else: ?>
            <a href="login.php?logout=1">تسجيل خروج</a>
        <?php endif; ?>
    </nav>
</header>

<section class="hero">
    <h1>ابحث عن وظيفة أحلامك في بوابة وظيفتي</h1>
    <form action="search.php" method="GET" class="search-container">
        <input type="text" name="q" placeholder="اسم الوظيفة أو الشركة..." required>
        <button type="submit">بحث</button>
    </form>
</section>

<div class="container">
    <div class="jobs-grid">
        <?php while($job = $jobs->fetch_assoc()): 
            $c_id = $job['company_id'];
            $imgSrc = isset($companyData[$c_id]) ? $companyData[$c_id]['img'] : 'images/default.png';
        ?>
            <div class="job-card">
                <div>
                    <img src="<?= $imgSrc ?>" class="company-img" onerror="this.src='images/default.png'" alt="شعار الشركة">
                    <h3><?= htmlspecialchars($job['title']) ?></h3>
                    <p style="color:#64748b; margin-bottom:10px;"><?= htmlspecialchars($job['company_name'] ?? 'شركة غير محددة') ?></p>
                </div>
                <a href="job.php?id=<?= $job['id'] ?>" class="btn-view">عرض التفاصيل</a>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>