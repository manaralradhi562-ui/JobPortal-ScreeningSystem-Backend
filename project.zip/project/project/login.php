<?php
session_start();

if(isset($_POST['login'])){
    // هنا يتم إضافة منطق التحقق من قاعدة البيانات لاحقاً
    $_SESSION['user_id'] = rand(1000,9999);
    header("Location: index.php");
    exit;
}

if(isset($_GET['logout'])){
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>وظيفتي - بوابة التوظيف الاحترافية</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap');
        
        body { 
            margin: 0; 
            min-height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            background: #0b0f14;
            background-image: radial-gradient(circle at 50% 50%, #1a2a3a 0%, #0b0f14 100%);
            font-family: 'Cairo', sans-serif;
            padding: 20px; /* إضافة حشوة جانبية للهاتف */
        }

        .glass-box { 
            width: 100%; 
            max-width: 400px; /* العرض الأقصى للشاشات الكبيرة */
            padding: 40px 20px; 
            border-radius: 30px;
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center; 
            color: white;
            box-shadow: 0 30px 70px rgba(0,0,0,0.5);
        }

        .logo { width: 150px; margin-bottom: 20px; }

        input { 
            width: 100%; 
            padding: 15px; 
            margin: 10px 0; 
            border: none; 
            border-radius: 15px; 
            background: rgba(255,255,255,0.05); 
            color: white;
            border: 1px solid rgba(255,255,255,0.1);
            box-sizing: border-box; /* هام جداً للحفاظ على العرض مع الحشوة */
        }

        button { 
            width: 100%; 
            padding: 15px; 
            margin-top: 20px; 
            border: none; 
            border-radius: 15px; 
            background: linear-gradient(135deg, #00c6ff, #0072ff); 
            color: white; 
            font-size: 16px; 
            font-weight: bold; 
            cursor: pointer;
        }

        .footer-link { 
            margin-top: 20px; 
            display: block; 
            color: rgba(255,255,255,0.5); 
            text-decoration: none; 
            font-size: 14px; 
        }
    </style>
</head>
<body>

<div class="glass-box">
    <img src="logo.png" alt="وظيفتي" class="logo">
    
    <h2>أهلاً بعودتك</h2>
    <p style="color:rgba(255,255,255,0.6); margin-bottom: 20px;">سجل دخولك للوصول إلى آلاف الفرص</p>
    
    <form method="POST">
        <input type="text" name="email" placeholder="البريد الإلكتروني" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <button name="login">تسجيل الدخول</button>
    </form>
    
    <a href="index.php" class="footer-link">العودة للصفحة الرئيسية</a>
</div>

</body>
</html>