<?php
session_start();
include("db.php");

$error = "";

if(isset($_POST['login'])){

    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND email=?");
    $stmt->bind_param("ss",$username,$email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){

        $user = $result->fetch_assoc();

        if(password_verify($password,$user['password'])){

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            if($user['role']=="admin"){
                header("Location: admin.php");
            } elseif($user['role']=="company"){
                header("Location: company_dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit();

        } else {
            $error = "❌ كلمة المرور خطأ";
        }

    } else {
        $error = "❌ الحساب غير موجود";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>تسجيل الدخول</title>

<style>
body{
    font-family:Arial;
    background:#0f172a;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:#1e293b;
    padding:30px;
    width:400px;
    border-radius:15px;
}

input{
    width:100%;
    padding:10px;
    margin:10px 0;
}

button{
    width:100%;
    padding:10px;
    background:#38bdf8;
    border:none;
    color:white;
}

.error{
    color:red;
    text-align:center;
}
</style>
</head>

<body>

<div class="box">

<h2>تسجيل الدخول</h2>

<div class="error"><?= $error ?></div>

<form method="POST">

<input type="text" name="username" placeholder="اسم المستخدم">

<input type="email" name="email" placeholder="الإيميل">

<input type="password" name="password" placeholder="كلمة المرور">

<button name="login">دخول</button>

</form>

</div>

</body>
</html>