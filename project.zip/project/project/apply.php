<?php
include("db.php");
include("data.php"); // استدعاء مصفوفة الصور والأوصاف

$id = intval($_GET['id'] ?? 0);

// استعلام لجلب بيانات الوظيفة

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$job = $result->fetch_assoc();

if (!$job) { 
    die("<div style='text-align:center; padding:50px; font-family:sans-serif; color:#ef4444;'>❌ الوظيفة غير موجودة</div>"); 
}

// جلب الصورة بناءً على ID الشركة من مصفوفة $companyData المتوفرة في ملف data.php
$c_id = $job['company_id'];
$imgSrc = isset($companyData[$c_id]) ? $companyData[$c_id]['img'] : 'images/default.png';
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقديم الطلب | <?= htmlspecialchars($job['title']) ?></title>
    <style>
        :root { 
            --primary: #2563eb; 
            --dark: #1e293b; 
            --light: #f8fafc; 
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        body { 
            background: var(--light); 
            padding: 30px 15px; 
            color: var(--dark); 
            line-height: 1.6;
            overflow-x: hidden;
        }
        .container { 
            max-width: 600px; 
            margin: 0 auto; 
            background: #fff; 
            padding: 40px 30px; 
            border-radius: 24px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.05); 
            text-align: center; 
        }
        
        /* تصميم أيقونة الشركة */
        .company-logo-main { 
            width: 110px; 
            height: 110px; 
            border-radius: 20px; 
            object-fit: contain; 
            margin-bottom: 15px; 
            border: 4px solid #f1f5f9; 
            padding: 8px; 
            background: white;
        }
        
        h2 { 
            color: var(--dark); 
            font-size: 1.6rem;
            margin-bottom: 5px; 
            font-weight: 700;
        }
        .job-title { 
            color: var(--primary); 
            font-size: 1.25rem; 
            font-weight: 600;
            margin-bottom: 25px; 
        }
        
        /* تنسيق الأزرار */
        .btn-main { 
            background: var(--primary); 
            color: #fff; 
            border: none; 
            padding: 14px 25px; 
            border-radius: 14px; 
            cursor: pointer; 
            font-size: 1rem; 
            font-weight: bold; 
            width: 100%; 
            transition: all 0.2s ease; 
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        }
        .btn-main:hover { 
            background: #1d4ed8; 
            transform: translateY(-1px); 
        }
        
        .upload-section { 
            margin-top: 30px; 
            border-top: 2px solid #f1f5f9; 
            padding-top: 25px; 
        }
        .upload-section p {
            font-weight: 600;
            color: #475569;
            margin-bottom: 10px;
        }
        
        /* حقل رفع الملفات المتجاوب */
        input[type="file"] { 
            margin: 15px 0 20px; 
            display: block; 
            width: 100%; 
            padding: 12px; 
            border: 2px dashed #cbd5e1; 
            border-radius: 12px; 
            background: #f8fafc;
            cursor: pointer;
            font-size: 0.95rem;
        }
        input[type="file"]:focus {
            border-color: var(--primary);
            outline: none;
        }
        
        /* تحسينات مخصصة للهواتف الشاشات الصغيرة */
        @media (max-width: 480px) {
            body {
                padding: 15px 10px;
            }
            .container { 
                padding: 30px 15px; 
                border-radius: 16px;
            }
            .company-logo-main { 
                width: 90px; 
                height: 90px; 
                border-radius: 16px;
            }
            h2 { 
                font-size: 1.35rem; 
            }
            .job-title { 
                font-size: 1.1rem; 
                margin-bottom: 20px;
            }
            .btn-main {
                padding: 12px 20px;
                font-size: 0.95rem;
                border-radius: 10px;
            }
            .upload-section { 
                margin-top: 25px; 
                padding-top: 20px; 
            }
            input[type="file"] {
                padding: 10px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <img src="<?= $imgSrc ?>" class="company-logo-main" onerror="this.src='images/default.png'" alt="شعار الشركة">
    
    <h2>التقديم على وظيفة</h2>
    <div class="job-title"><?= htmlspecialchars($job['title']) ?></div>

    <a href="questions.php?id=<?= $job['id'] ?>" style="text-decoration:none; display:block; margin-bottom: 10px;">
        <button class="btn-main">متابعة إلى الأسئلة 🚀</button>
    </a>

    <div class="upload-section">
        <form action="upload_cv.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $job['id'] ?>">
            <p>📄 ارفع سيرتك الذاتية (CV)</p>
            <input type="file" name="cv" accept=".pdf,.doc,.docx" required>
            <button type="submit" class="btn-main" style="background: #0f172a; box-shadow: 0 4px 12px rgba(15, 23, 42, 0.15);">إرسال الطلب الآن</button>
        </form>
    </div>
</div>

</body>
</html>