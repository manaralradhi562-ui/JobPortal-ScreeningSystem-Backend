<?php
include("db.php");
include("data.php"); // استدعاء المصفوفة الموحدة للصور والأوصاف

$id = intval($_GET['id'] ?? 0);
if($id <= 0) die("<div style='text-align:center; padding:50px; font-family:sans-serif; color:#ef4444;'>❌ رقم الوظيفة غير صحيح</div>");

// جلب بيانات الوظيفة
$stmt = $conn->prepare("SELECT jobs.*, companies.company_name FROM jobs JOIN companies ON jobs.company_id = companies.id WHERE jobs.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

if(!$job) die("<div style='text-align:center; padding:50px; font-family:sans-serif; color:#ef4444;'>❌ الوظيفة غير موجودة</div>");

// جلب صورة الشركة من المصفوفة
$c_id = $job['company_id'];
$imgSrc = isset($companyData[$c_id]) ? $companyData[$c_id]['img'] : 'images/default.png';

// الأسئلة (استخدمنا الأسماء كما هي في المصفوفة السابقة لضمان التوافق)
$questionsBank = [
    'google' => ["لماذا تريد العمل في Google؟", "هل لديك خبرة في Machine Learning؟", "ما مشاريع الذكاء الاصطناعي التي عملت عليها؟"],
    'amazon' => ["كيف تبني نظام Backend قوي؟", "خبرتك في AWS أو PHP؟", "كيف تدير نظام E-commerce كبير؟"],
    // ... يمكنك إضافة باقي الشركات هنا بنفس الطريقة
];

$companyName = strtolower($job['company_name']);
$qs = $questionsBank[$companyName] ?? ["لماذا تريد هذه الوظيفة؟", "ما خبرتك في هذا المجال؟", "لماذا نختارك أنت لهذه الوظيفة؟"];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مقابلة: <?= htmlspecialchars($job['title']) ?> | وظيفتي 2026</title>
    <style>
        :root { 
            --primary: #2563eb; 
            --accent: #38bdf8;
            --dark-bg: #0f172a; 
            --card-bg: rgba(255, 255, 255, 0.05);
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        body { 
            background: var(--dark-bg); 
            color: #fff; 
            margin: 0; 
            padding: 30px 15px; 
            line-height: 1.6;
            overflow-x: hidden;
        }
        .container { 
            max-width: 700px; 
            margin: 0 auto; 
            background: var(--card-bg); 
            padding: 40px 30px; 
            border-radius: 24px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.3); 
            border: 1px solid rgba(255,255,255,0.05);
        }
        
        /* تصميم أيقونة الشركة المحسن */
        .comp-logo { 
            width: 100px; 
            height: 100px; 
            border-radius: 20px; 
            margin-bottom: 20px; 
            border: 2px solid rgba(255,255,255,0.1); 
            object-fit: contain;
            background: rgba(255, 255, 255, 0.9); /* خلفية بيضاء خفيفة لتبرز اللوجوهات الشفافة الداكنة */
            padding: 5px;
        }
        
        h3 { 
            font-size: 1.6rem; 
            margin-bottom: 10px; 
            color: var(--accent); 
            font-weight: 700;
        }
        .job-sub {
            margin-bottom: 30px; 
            opacity: 0.8;
            font-size: 1.1rem;
        }
        
        .q-box { 
            margin-bottom: 25px; 
            text-align: right;
        }
        .q-box label {
            font-size: 1.05rem;
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
            color: #e2e8f0;
        }
        
        /* تحسين الـ Textarea ليكون متجاوباً ومريحاً للكتابة بالهواتف */
        textarea { 
            width: 100%; 
            height: 120px; 
            background: rgba(255,255,255,0.07); 
            border: 1px solid rgba(255,255,255,0.15); 
            border-radius: 14px; 
            padding: 12px 15px; 
            color: white; 
            resize: none; 
            font-size: 1rem;
            outline: none;
            transition: all 0.2s ease;
        }
        textarea:focus { 
            border-color: var(--accent); 
            background: rgba(255,255,255,0.1);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        }
        
        /* زر الإرسال المتجاوب */
        button { 
            width: 100%; 
            padding: 16px; 
            background: var(--primary); 
            color: #fff; 
            border: none; 
            border-radius: 14px; 
            font-weight: bold; 
            font-size: 1.1rem; 
            cursor: pointer; 
            transition: all 0.2s ease; 
            margin-top: 10px;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
        }
        button:hover { 
            background: #1d4ed8; 
            transform: translateY(-1px);
        }

        /* تحسينات مخصصة للهواتف والشاشات الصغيرة */
        @media (max-width: 480px) {
            body {
                padding: 15px 10px;
            }
            .container { 
                padding: 30px 15px; 
                border-radius: 16px;
            }
            .comp-logo { 
                width: 85px; 
                height: 85px; 
                border-radius: 16px;
                margin-bottom: 15px;
            }
            h3 { 
                font-size: 1.3rem; 
            }
            .job-sub {
                font-size: 0.95rem;
                margin-bottom: 25px;
            }
            .q-box label {
                font-size: 0.95rem;
            }
            textarea {
                padding: 10px;
                font-size: 0.95rem;
                height: 110px;
                border-radius: 10px;
            }
            button {
                padding: 14px;
                font-size: 1rem;
                border-radius: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <img src="<?= $imgSrc ?>" class="comp-logo" onerror="this.src='images/default.png'" alt="شعار الشركة">
    <h3>المقابلة الوظيفية في <?= htmlspecialchars($job['company_name']) ?></h3>
    <p class="job-sub"><?= htmlspecialchars($job['title']) ?></p>

    <form action="success.php" method="post">
        <input type="hidden" name="job_id" value="<?= $id ?>">

        <?php foreach($qs as $index => $q): ?>
            <div class="q-box">
                <label><?= ($index + 1) . '. ' . htmlspecialchars($q) ?></label>
                <textarea name="answers[]" required placeholder="اكتب إجابتك هنا..."></textarea>
            </div>
        <?php endforeach; ?>

        <button type="submit">إرسال الإجابات وإنهاء المقابلة 🚀</button>
    </form>
</div>

</body>
</html>